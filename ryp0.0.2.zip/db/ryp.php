<?php

include_once("db.php");

include_once("oracledb.php");

function sendPasswordResetLink($conn, $email, $name) {
    $linkVal = md5(strval(rand()));
    global $baseUrl;
    $link = $baseUrl . "resetPassword.html?link=" . $linkVal;
    dml($conn, "update z_ryp_users set pwd_reset_link = :link, reset_link_date = sysdate where lower(email) = lower(:email)", [ 'vals' => ['link' => $linkVal, 'email' => $email]]);
    $tpl = file_get_contents("register_email.txt");
    $text = str_replace("{name}", $name, $tpl);
    $text = str_replace("{link}", $link, $text);
    $headers = 'From: donotreply@mountsinai.org' . "\r\n" .
        'Reply-To: donotreply@mountsinai.org' . "\r\n" .
        'X-Mailer: PHP/' . phpversion();
    mail ( $email, "Reach your peak - Please verify your email", $text, $headers);
}

function errorMSG($msg, $data) {
	$r = [ "result" => "error", "error" => $msg ];
	if(isset($data)) {
		array_merge($r, $data);
	}
	echo json_encode($r);
}


function getUserFromEmail($conn, $email) {
    //echo '---- ' . $email . ' ---- ';
    $res = sqlToJSON($conn, "select * from z_ryp_users where lower(email) = lower(:email)", [ "vals" => [ "email" => $email]]);
    if(isset($res) && sizeof($res) > 0) return $res[0];
    return null;
}

function createSession($conn, $id) {
    $sessionKey = md5(strval(rand()));
    dml($conn, "update z_ryp_users set session_key = :sk, last_logged_in = sysdate where id = :id", [ 'vals' => ['id' => $id, 'sk' => $sessionKey]]);
    return $sessionKey;
}

function checkSession($conn, $email, $sessionKey, $userid) {
    //echo '---- ' . $email . ' ---- ';
    $user = getUserFromEmail($conn, $email);
    //var_dump($user);
    //echo $userid . ' 00 ' . strval($user['ID']). ' 00 ' . $sessionKey. ' -0 ' . $user['SESSION_KEY'];
    if($sessionKey == $user['SESSION_KEY'] && $userid == strval($user['ID'])) {
        return $user;
    } else {
        return null;
    }
}

function hasValidSession($conn) {
    // all 3 have to match:  id, email and sessionKey.   
	if(isset($_COOKIE) && isset($_COOKIE['sessionKey']) && isset($_COOKIE['email']) && isset($_COOKIE['userid'])) {
		return checkSession($conn, $_COOKIE['email'], $_COOKIE['sessionKey'], $_COOKIE['userid']);
	} 
	return null;
}

function exitNoSession($conn) {
    if(!hasValidSession($conn)) {
        errorMSG('No valid session', []);
        die();
    }
}

function logout($conn) {
    $email = $_COOKIE['email'];
    $sk = $_COOKIE['sessionKey'];
    dml($conn, "update z_ryp_users set session_key = ''  where email = :email and session_key = :sk", 
    [ 'vals' => ['email' => $email, 'sk' => $sk]]);
    json_data('You have logged out', ['data' => []]);
}

function getRoles($conn) {
    return sqlToJSON($conn, "select * from z_ryp_roles order by name", []);
}

function getRoleID($conn, $name) {
    $roles = getRoles($conn);
     for($i=0; $i<sizeof($roles); $i++) {
        if($roles[$i]['NAME'] == $name) {
            return $roles[$i]['ID'];
        }
    }
    return null;
}

function removeAdminRole($conn, $userid, $roleId) {
    if(isset($roleId)){
        dml($conn, "delete from z_ryp_role_members where user_id = :userid and role_id = :roleid", 
            [ 'vals' => [ 'userid' => $userid, 'roleid' => $roleId]]);  
        
    }
}

function addAdminRole($conn, $userid) {
    $roleId = getRoleID($conn, 'Admin');
     
    removeAdminRole($conn, $userid, $roleId);
    dml($conn, 'insert into z_ryp_role_members (id, role_id, user_id) values (z_ryp_role_members_id_seq.nextval, :roleid, :userid)', 
            [ 'vals' => [ 'userid' => $userid, 'roleid' => $roleId]]);
}

function getCycles($conn, $activeFlag) {
    return sqlToJSON($conn, "select * from z_ryp_cycle where active_flag = :f  order by name", [ 'vals' => ['f' => $activeFlag]]);   
}

function getTeamByName($conn, $name) {
    return getFirstRecord($conn, "select * from z_ryp_team where lower(name) = lower(:name)", [ 'vals' => ['name' => $name]]);
}

function getAllActiveTeams($conn) {
    $sql = "select * from z_ryp_team";
    return sqlToJSON($conn, $sql, []);
}

function assignRoleToTeam($conn, $userid, $cycle_team_id, $role_id) {
    
    dml($conn, "delete from z_ryp_role_members where role_id = :role_id and team_id = :team_id and user_id = :user_id",
        [ "vals" => [ 'role_id' => intval($role_id), 'user_id' => intval($userid), 'team_id' => intval($cycle_team_id) ]]
    );    
    
    dml($conn, "insert into z_ryp_role_members(id, role_id, user_id, team_id) values (z_ryp_role_members_id_seq.nextval, :role_id, :user_id, :team_id)",
        [ "vals" => [ 'role_id' => intval($role_id), 'user_id' => intval($userid), 'team_id' => intval($cycle_team_id) ]]
    );    
}

function assignCaptain($conn, $userid, $cycle_team_id) {
    $role_id = getRoleID($conn, 'Captain');
    assignRoleToTeam($conn, $userid, $cycle_team_id, $role_id);
}
  
function startTeam($conn, $name, $cycleId, $userid) {
    $team = getTeamByName($conn, $name);
    if($team) {
        errorMSG("This team already exists.  Please pick another name.", []);
    } else {
        dml($conn, "insert into z_ryp_team(id, name, active_flag) values (z_ryp_team_id_seq.nextval, :name, 'E')", 
            [ 'vals' => [ 'name' => $name]]);
        $team = getTeamByName($conn, $name);
        $id = $team['ID'];
        dml($conn, "insert into z_ryp_team_cycles (id, team_id, cycle_id, active_flag) values (z_ryp_team_cycles_id_seq.nextval, :team, :cycle, 'E')", 
            [ 'vals' => [ 'team' => $id, 'cycle' => $cycleId]]);
            
        $cid = getFirstRecord($conn, "select * from z_ryp_team_cycles where cycle_id = :cycle and team_id = :team", 
            [ 'vals' => [ 'team' => $id, 'cycle' => $cycleId]]);
        assignCaptain($conn, $userid, $cid['ID']);
    }
}
  
function getTeamMembership($conn, $user_id) {
    // only get active or enroll teams.
    $sql = "select u.name, t.name as team_name, r.name as role_name, c.name as cycle_name, c.start_date, c.end_date from z_ryp_users u 
join z_ryp_role_members m on u.id = m.user_id
join z_ryp_team_cycles tc on tc.id = m.team_id
join z_ryp_team t on t.id = tc.team_id
join z_ryp_roles r on m.role_id = r.id
join z_ryp_cycle c on tc.cycle_id = c.id
where t.active_flag in ('E', 'A') and u.id = :id";
    $res = getFirstRecord($conn, $sql, [ 'vals' => [ 'id' => $user_id]]);
    return $res;
}

function isAdmin($conn, $userid) {
    $sql = "select u.name,  r.name as role_name from z_ryp_users u 
join z_ryp_role_members m on u.id = m.user_id
join z_ryp_roles r on m.role_id = r.id
where r.name = 'Admin' and u.id = :id";
    $res = getFirstRecord($conn, $sql, [ 'vals' => [ 'id' => $userid]]);
    return $res;
}

function exitNoAdmin($conn, $userid) {
    if(! isAdmin($conn, $userid)) {
        errorMSG("No admin privileges");
        die();
    }
}
  
?>