<?php

include_once("ryp.php");

$conn = openANCPROD();

try {
    dml($conn, 
        "update z_ryp_users set password = :password, verified_flag='Y' where pwd_reset_link = :link", 
            [ 'vals' => [ "password" => md5($_POST['password']), "link" => $_POST['link']]] );
} catch(Exception $e) {
    errorMSG($e);
    die();
}

json_data('Password has been reset.  Now please log in.', []);

?>