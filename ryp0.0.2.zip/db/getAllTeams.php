<?php

include_once("ryp.php");

$conn = openANCPROD();

$res = getAllActiveTeams($conn);
json_data('All teams retrieved', $res);

echo " Hello";

?>