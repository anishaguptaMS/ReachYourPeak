<?php

include_once("ryp.php");

$conn = openANCPROD();

exitNoSession($conn);

exitNoAdmin($conn, $_COOKIE['userid']);

$sql = "select * from z_ryp_locations";


$data = getRSET($conn, [ 
		"sql" => $sql,
		'dt' => true
	]);
	

json_data("Locations", 
	$data
);

?>

