<?php

include_once("ryp.php");

$conn = openANCPROD();

startTeam($conn, $_POST['name'], $_POST['cycleId'], $_COOKIE['userid']);

json_data("Team created", []);

?>
