<?php

include_once("ryp.php");

$conn = openANCPROD();

exitNoSession($conn);

exitNoAdmin($conn, $_COOKIE['userid']);

$sql = "select u.id, u.name, t.name as team_name, r.name as role_name, c.name as cycle_name from z_ryp_users u 
join z_ryp_role_members m on u.id = m.user_id
join z_ryp_team_cycles tc on tc.id = m.team_id
join z_ryp_team t on t.id = tc.team_id
join z_ryp_roles r on m.role_id = r.id
join z_ryp_cycle c on tc.cycle_id = c.id
where t.active_flag in ('E', 'A')";


$data = getRSET($conn, [ 
		"sql" => $sql,
		'dt' => true
	]);
	
//var_dump($data);	

json_data("Users", 
	$data
);

?>

