<?php

include_once("ryp.php");

$conn = openANCPROD();

json_data('Cycles retrieved', getCycles($conn, $_GET['status']));


?>