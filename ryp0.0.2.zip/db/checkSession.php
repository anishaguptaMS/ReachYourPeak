<?php

include_once("ryp.php");

$conn = openANCPROD();

$res = hasValidSession($conn);

if($res) {

    echo json_data ('Valid session',  [ 'hasSession' => true, 'name' => $res['NAME']]);

}  else {
    echo json_encode ([ 'result' => 'OK', 'data' => [ 'hasSession' => false]]);
    
}


?>