<?php

include_once("ryp.php");

$conn = openANCPROD();

logout($conn);

?>