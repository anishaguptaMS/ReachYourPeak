<?php

include_once("ryp.php");

$conn = openANCPROD();

exitNoSession($conn);

$user_id = $_COOKIE['userid'];

$res = getTeamMembership($conn, $user_id);

json_data('Team membership', $res);



?>