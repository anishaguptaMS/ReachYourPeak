<?php

include_once("ryp.php");

$conn = openANCPROD();

try {
    dml($conn, 
        "insert into z_ryp_users (id, name, email, verified_flag) values (z_ryp_users_id_seq.nextval, :name, :email, 'N')", [ 'vals' => $_POST] );
} catch(Exception $e) {
    echo " Error !!!!! ";
    errorMSG($e);
    die();
}

sendPasswordResetLink($conn, $_POST['email'], $_POST['name']);
json_data('Registration is completed.  Wait for email to confirm', []);

?>