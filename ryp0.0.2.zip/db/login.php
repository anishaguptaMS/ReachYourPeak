<?php

include_once("ryp.php");

$conn = openANCPROD();

if(isset($_POST) && isset($_POST['email'])) {
    $email = $_POST['email'];
} else if(isset($_GET)) {
    $email = $_GET['email'];
}    

$user = getUserFromEmail($conn, $email);

if(isset($user) && $user['PASSWORD'] == md5($_POST['password'])) {
    $sessionKey = createSession($conn, $user['ID']);
    json_data('Login correct', [ 'sessionKey' => $sessionKey, 'id' => $user['ID'], 'name' => $user['NAME']]);
} else {
    errorMSG("Email or password is incorrect", [ "data" => [] ]);
    
}

?>