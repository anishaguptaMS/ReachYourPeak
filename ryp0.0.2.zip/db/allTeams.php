<?php

include_once("ryp.php");

$conn = openANCPROD();

exitNoSession($conn);

exitNoAdmin($conn, $_COOKIE['userid']);

$sql = "select * from z_ryp_team";


$data = getRSET($conn, [ 
		"sql" => $sql,
		'dt' => true
	]);
	
//var_dump($data);	

json_data("Teams", 
	$data
);

?>

